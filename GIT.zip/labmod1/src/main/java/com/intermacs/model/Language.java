package com.intermacs.model;
public enum Language {
	ENGLISH, SPANISH, FRENCH
}