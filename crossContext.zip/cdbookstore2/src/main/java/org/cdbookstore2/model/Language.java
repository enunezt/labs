package org.cdbookstore2.model;
public enum Language {
	ENGLISH, FRENCH
}