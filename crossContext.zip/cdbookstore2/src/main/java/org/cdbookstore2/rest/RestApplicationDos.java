package org.cdbookstore2.rest;

import javax.ws.rs.core.Application;
import javax.ws.rs.ApplicationPath;

@ApplicationPath("/rest2")
public class RestApplicationDos extends Application {
}