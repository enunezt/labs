package org.cdbookstore.rest.dto;

import java.io.Serializable;
import org.cdbookstore.model.Author;
import javax.persistence.EntityManager;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class AuthorDTO implements Serializable {

	private Long id;
	private int version;
	private String firstName;

	public AuthorDTO() {
	}

	public AuthorDTO(final Author entity) {
		if (entity != null) {
			this.id = entity.getId();
			this.version = entity.getVersion();
			this.firstName = entity.getFirstName();
		}
	}

	public Author fromDTO(Author entity, EntityManager em) {
		if (entity == null) {
			entity = new Author();
		}
		entity.setVersion(this.version);
		entity.setFirstName(this.firstName);
		entity = em.merge(entity);
		return entity;
	}

	public Long getId() {
		return this.id;
	}

	public void setId(final Long id) {
		this.id = id;
	}

	public int getVersion() {
		return this.version;
	}

	public void setVersion(final int version) {
		this.version = version;
	}

	public String getFirstName() {
		return this.firstName;
	}

	public void setFirstName(final String firstName) {
		this.firstName = firstName;
	}
}