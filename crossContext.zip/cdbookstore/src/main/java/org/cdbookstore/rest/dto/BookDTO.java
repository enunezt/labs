package org.cdbookstore.rest.dto;

import java.io.Serializable;
import org.cdbookstore.model.Book;
import javax.persistence.EntityManager;
import org.cdbookstore.model.Language;
import org.cdbookstore.rest.dto.NestedAuthorDTO;
import java.util.Date;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class BookDTO implements Serializable {

	private Long id;
	private int version;
	private String title;
	private Language languaje;
	private NestedAuthorDTO author;
	private Date publicationDate;
	private String description;

	public BookDTO() {
	}

	public BookDTO(final Book entity) {
		if (entity != null) {
			this.id = entity.getId();
			this.version = entity.getVersion();
			this.title = entity.getTitle();
			this.languaje = entity.getLanguaje();
			this.author = new NestedAuthorDTO(entity.getAuthor());
			this.publicationDate = entity.getPublicationDate();
			this.description = entity.getDescription();
		}
	}

	public Book fromDTO(Book entity, EntityManager em) {
		if (entity == null) {
			entity = new Book();
		}
		entity.setVersion(this.version);
		entity.setTitle(this.title);
		entity.setLanguaje(this.languaje);
		if (this.author != null) {
			entity.setAuthor(this.author.fromDTO(entity.getAuthor(), em));
		}
		entity.setPublicationDate(this.publicationDate);
		entity.setDescription(this.description);
		entity = em.merge(entity);
		return entity;
	}

	public Long getId() {
		return this.id;
	}

	public void setId(final Long id) {
		this.id = id;
	}

	public int getVersion() {
		return this.version;
	}

	public void setVersion(final int version) {
		this.version = version;
	}

	public String getTitle() {
		return this.title;
	}

	public void setTitle(final String title) {
		this.title = title;
	}

	public Language getLanguaje() {
		return this.languaje;
	}

	public void setLanguaje(final Language languaje) {
		this.languaje = languaje;
	}

	public NestedAuthorDTO getAuthor() {
		return this.author;
	}

	public void setAuthor(final NestedAuthorDTO author) {
		this.author = author;
	}

	public Date getPublicationDate() {
		return this.publicationDate;
	}

	public void setPublicationDate(final Date publicationDate) {
		this.publicationDate = publicationDate;
	}

	public String getDescription() {
		return this.description;
	}

	public void setDescription(final String description) {
		this.description = description;
	}
}