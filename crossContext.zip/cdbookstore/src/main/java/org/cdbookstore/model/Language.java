package org.cdbookstore.model;
public enum Language {
	ENGLISH, SPANISH, FRENCH
}