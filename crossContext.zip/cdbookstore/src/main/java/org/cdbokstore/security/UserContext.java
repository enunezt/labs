package org.cdbokstore.security;
import java.security.Principal;

public class UserContext implements Principal {
  
  private String name;
  
  public UserContext(String name) {
    super();
    this.name = name;
  }

  public void setName(String name) {
    this.name = name;
  }

  @Override
  public String getName() {
    return name;
  }

}