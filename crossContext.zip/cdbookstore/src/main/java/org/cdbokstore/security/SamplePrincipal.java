package org.cdbokstore.security;
import java.security.Principal;
import java.util.Set;

import javax.security.auth.Subject;
 
public class SamplePrincipal implements Principal {
 
    private String _name = null;
    private Subject _subject;
        
    public SamplePrincipal(Subject subject,String name) {
        _name = name;
       _subject=subject;
    }
    public void printPrincipals(){
    Set<Principal>	_lst=_subject.getPrincipals();
    for (Principal principal : _lst) {
		System.out.println(principal.getName()); 
	}
    }
    
 
    public SamplePrincipal(String name) {
        _name = name;
    }
 
    
    public boolean equals(Object another) {
        return ((SamplePrincipal)another).getName().equals(_name);
    }
 
 
    public String getName() {
        return _name;
    }
 
 
    public int hashCode() {
        return _name.hashCode();
    }
 
 
    public String toString() {
        return "[SamplePrincipal] : " + _name;
    }
 
}