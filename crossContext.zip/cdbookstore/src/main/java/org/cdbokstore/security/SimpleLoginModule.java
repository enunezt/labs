package org.cdbokstore.security;

import java.util.Map;

import javax.enterprise.context.spi.CreationalContext;
import javax.enterprise.inject.spi.Bean;
import javax.enterprise.inject.spi.BeanManager;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.security.auth.Subject;
import javax.security.auth.callback.Callback;
import javax.security.auth.callback.CallbackHandler;
import javax.security.auth.callback.NameCallback;
import javax.security.auth.callback.PasswordCallback;
import javax.security.auth.login.LoginException;
import javax.security.auth.spi.LoginModule;

import org.cdbookstore.model.Author;
import org.cdbookstore.view.AuthorBean;

/**
 * @author blep
 *         Date: 12/02/12
 *         Time: 11:59
 */

public class SimpleLoginModule implements LoginModule
{

   // ======================================
   // =             Attributes             =
   // ======================================

   private CallbackHandler callbackHandler;

   private AuthorBean customerService;

   private BeanManager beanManager;
   private Subject subject;
  private  UserContext userPrincipal;
   //private UserPrincipal userPrincipal;
   //private RolePrincipal rolePrincipal;

   // ======================================
   // =          Business methods          =
   // ======================================

   private AuthorBean getCustomerService()
   {
      if (customerService != null)
      {
         return customerService;
      }
      try
      {
         Context context = new InitialContext();
         beanManager = (BeanManager) context.lookup("java:comp/BeanManager");
         Bean<?> bean = beanManager.getBeans(AuthorBean.class).iterator().next();
         CreationalContext cc = beanManager.createCreationalContext(bean);
         customerService = (AuthorBean) beanManager.getReference(bean, AuthorBean.class, cc);

      }
      catch (NamingException e)
      {
         e.printStackTrace();
         throw new RuntimeException(e);
      }

      return customerService;

   }

   @Override
   public void initialize(Subject subject, CallbackHandler callbackHandler, Map<String, ?> stringMap, Map<String, ?> stringMap1)
   {
      this.callbackHandler = callbackHandler;
      getCustomerService();
      this.subject=subject;
   }

   @Override
   public boolean login() throws LoginException
   {

      NameCallback nameCallback = new NameCallback("Name : ");
      PasswordCallback passwordCallback = new PasswordCallback("Password : ", false);
      try
      {
         callbackHandler.handle(new Callback[]{nameCallback, passwordCallback});
         String username = nameCallback.getName();
         String password = new String(passwordCallback.getPassword());
         nameCallback.setName("");
         passwordCallback.clearPassword();
         Author author = customerService.getAuthor();
         
        

        /* if (author == null)
         {
            throw new LoginException("Authentication failed");
         }*/

         
         userPrincipal = new UserContext(username);
         subject.getPublicCredentials().add(new RolContext("ADMINISTRATOR")); 
         subject.getPrincipals().add(userPrincipal);
         subject.getPrincipals().add(new RolContext("ADMINISTRATOR")); 
         
         return true;
      }
      catch (Exception e)
      {
         e.printStackTrace();
         throw new LoginException(e.getMessage());
      }
   }

   @Override
   public boolean commit() throws LoginException
   {
      return true;
   }

   @Override
   public boolean abort() throws LoginException
   {
      return true;
   }

   @Override
   public boolean logout() throws LoginException
   {
	   
	   subject.getPrincipals().remove(userPrincipal);
      return true;
   }
   
   
}
