package org.cdbokstore.security;

import java.security.Principal;

public class RolContext implements Principal {
  
  private String name;
  private RolContext hijo;
  
  public RolContext(String name) {
    super();
    this.name = name;
  }
  
  public void  addHijo(RolContext hijo){
  }

  public void setName(String name) {
    this.name = name;
  }

  @Override
  public String getName() {
    return name;
  }

}