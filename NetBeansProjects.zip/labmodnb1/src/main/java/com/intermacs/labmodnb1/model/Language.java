package com.intermacs.labmodnb1.model;
public enum Language {
	ENGLISH, SPANISH, FRENCH
}