package com.intermacs.labmodnb2.model;
public enum Language {
	ENGLISH, SPANISH, FRENCH
}