/**
 * 
 */
package com.intermacs.exceptions;

/**
 * @author ENUNEZT
 *
 */
@SuppressWarnings("serial")
public class ServicioFacadeExcepcion extends Exception {

	/**
	 * 
	 */
	public ServicioFacadeExcepcion() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param message
	 */
	public ServicioFacadeExcepcion(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param cause
	 */
	public ServicioFacadeExcepcion(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param message
	 * @param cause
	 */
	public ServicioFacadeExcepcion(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

}
