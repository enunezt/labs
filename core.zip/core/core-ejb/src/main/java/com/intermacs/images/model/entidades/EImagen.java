package com.intermacs.images.model.entidades;


public enum EImagen {
    FOTO,
    IMAGEN,
    FOTO_PERFIL
}