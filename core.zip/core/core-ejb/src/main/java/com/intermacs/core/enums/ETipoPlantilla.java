package com.intermacs.core.enums;
public enum ETipoPlantilla {
    HTML,
    XML,
    JRXML,
    JS
}