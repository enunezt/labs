/**
 * 
 */
package com.intermacs.exceptions;

/**
 * @author enunezt
 *
 */
@SuppressWarnings("serial")
public class ServicioExcepcion extends Exception {

	/**
	 * 
	 */
	public ServicioExcepcion() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param arg0
	 */
	public ServicioExcepcion(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param arg0
	 */
	public ServicioExcepcion(Throwable arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param arg0
	 * @param arg1
	 */
	public ServicioExcepcion(String arg0, Throwable arg1) {
		super(arg0, arg1);
		// TODO Auto-generated constructor stub
	}

}
