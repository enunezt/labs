package com.intermacs.images.model.entidades;
public enum ETipoImagen {
    jpg,
    png
}