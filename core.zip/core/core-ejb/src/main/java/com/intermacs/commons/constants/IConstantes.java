package com.intermacs.commons.constants;

public interface IConstantes {
	String FOTO_CAPTURA="caption";
	String PARAM_CONTEXT="settCtx";
	 Integer ID_PAIS_COL=52;
	 Long ID_USUARIO_PUBLICO=3L;
	 Long ID_USUARIO_ESTUDIANTE=2L;
}
