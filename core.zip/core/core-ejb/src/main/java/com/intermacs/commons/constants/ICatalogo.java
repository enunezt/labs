package com.intermacs.commons.constants;
/**
 * Define los catalogos principales y del sistema
 * @author intermacs
 *
 */
public interface ICatalogo {
	int TIPOS_DOCUMENTO=1;	
	int PROFESIONES_OFICIOS=1000;

}
