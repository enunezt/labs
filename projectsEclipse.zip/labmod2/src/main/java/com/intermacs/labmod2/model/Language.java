package com.intermacs.labmod2.model;
public enum Language {
	ENGLISH, FRENCH
}